import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image } from 'react-native';
import { Card, Button } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';

const personagens = () => {
    const [personagens, setPersonagens] = useState([]);
    const navigation = useNavigation();
    const navigateToActorDetails = (id) => {
        navigation.navigate('detalhes', { id });
    };

    useEffect(() => {
        fetch('https://my-json-server.typicode.com/orionteles/chavo/personagens')
            .then(response => response.json())
            .then(data => setPersonagens(data));
    }, []);

    return (
        <View style={{ marginTop: 5, margin: 5 }}>
            <Text style={{ fontSize: 24, textAlign: 'center', color: 'red' }}>Personagens do Chaves</Text>
            {personagens.map(item => (
                <Card style={{ marginTop: 10, margin: 10 }} mode='outlined'>
                    <Card.Title title={item.nome} />
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Image source={{ uri: item.urlImagem }} style={{ width: 50, height: 50, borderRadius: 25, marginRight: 8 }} />
                        <Text style={{ fontSize: 12, flex: 1 }}>{item.ator}</Text>
                        <Button
                            mode="text"
                            icon="chevron-right"
                            onPress={() => navigateToActorDetails(item.id)}
                            style={{ marginLeft: 'auto' }}
                        />
                    </View>
                </Card>
            ))}
        </View>
    );
};

export default personagens;
