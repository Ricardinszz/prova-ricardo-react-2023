import React, { useEffect, useState } from 'react';
import { View, Text, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const detalhes = ({ route }) => {
  const navigation = useNavigation();
  const { id } = route.params;
  const [ator, setAtor] = useState(null);

  useEffect(() => {
    fetch(`https://my-json-server.typicode.com/orionteles/chavo/personagens/${id}`)
      .then(response => response.json())
      .then(data => setAtor(data));
  }, [id]);

  if (!ator) {
    return <Text>Carregando...</Text>;
  }

  return (
    <View>
      <Image source={{ uri: ator.urlImagem }} style={{ width: 100, height: 100, borderRadius: 50, marginBottom: 15 }} />
      <Text style={{ fontSize: 24, marginBottom: 8 }}>{ator.nome}</Text>
      <Text style={{ fontSize: 16, marginBottom: 15 }}>{ator.ator}</Text>
      <Text>{ator.biografia}</Text>
    </View>
  );
};

export default detalhes;
