import React from 'react'

const bordoes = () => {
  return (
    <div>bordoes</div>
  )
}

export default bordoes